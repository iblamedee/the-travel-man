import "dotenv/config";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Helper to check if API key is present
const hasApiKey = () => {
  return !!process.env.GEMINI_API_KEY;
};

// API Routes
app.get("/api/config", (req, res) => {
  res.json({
    hasApiKey: hasApiKey()
  });
});

// Chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, preferences } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required" });
    }

    if (!hasApiKey()) {
      return res.status(400).json({ 
        error: "Gemini API key is not configured. Please add GEMINI_API_KEY to your Secrets panel." 
      });
    }

    // Prepare system instruction with preferences if available
    let systemInstruction = "You are Lyu, a visionary, futuristic, and highly intelligent AI Travel Partner. " +
      "You speak in a tech-forward, friendly, yet professional tone. You help users plan hyper-spatial journeys, " +
      "recommend hidden spots, local delicacies, and draft futuristic itineraries. Use sleek, engaging language.";
    
    if (preferences) {
      systemInstruction += ` Take into account the user's travel preferences: ` +
        `Home Airport/City: ${preferences.homeAirport || "Anywhere"}, ` +
        `Travel Budget: ${preferences.budget || "Moderate"}, ` +
        `Travel Style: ${preferences.style || "Balanced/Mixed"}, ` +
        `Interests: ${preferences.interests || "Nature, Cyberpunk, Culture"}.`;
    }

    // Map messages to Gemini format
    const contents = messages.map((msg: any) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.text }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Chat error:", error);
    res.status(500).json({ error: error.message || "Failed to generate chat response" });
  }
});

// Itinerary generation endpoint
app.post("/api/itinerary/generate", async (req, res) => {
  try {
    const { destination, duration, budget, style, preferences } = req.body;
    if (!destination) {
      return res.status(400).json({ error: "Destination is required" });
    }

    if (!hasApiKey()) {
      return res.status(400).json({ 
        error: "Gemini API key is not configured. Please add GEMINI_API_KEY to your Secrets panel." 
      });
    }

    const durationDays = parseInt(duration) || 3;
    const budgetLevel = budget || "moderate";
    const travelStyle = style || "balanced";

    let systemInstruction = "You are Lyu, an elite AI Travel Partner. Create a beautiful, detailed, day-by-day " +
      "itinerary for the given destination. Be creative, suggesting high-fidelity futuristic and traditional " +
      "spots. For each day, include a theme and suggest structured activities (Morning, Afternoon, Evening) " +
      "with estimated costs, specific beautiful location names, and immersive descriptions. " +
      "Also suggest 2-3 suitable hotels/accommodations with price levels and descriptions, " +
      "plus futuristic or smart flight/travel tips.";

    const prompt = `Generate a travel itinerary for:
Destination: ${destination}
Duration: ${durationDays} days
Budget Level: ${budgetLevel}
Travel Style: ${travelStyle}
${preferences ? `User Travel Preferences: Budget: ${preferences.budget}, Style: ${preferences.style}, Interests: ${preferences.interests}` : ""}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            destination: { type: Type.STRING },
            country: { type: Type.STRING },
            durationDays: { type: Type.INTEGER },
            bestSeason: { type: Type.STRING },
            budgetLevel: { type: Type.STRING },
            description: { type: Type.STRING, description: "A highly immersive, visionary summary of this destination's vibe." },
            estimatedTotalCost: { type: Type.STRING, description: "E.g., '$1,200 - $1,800 USD'" },
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  theme: { type: Type.STRING, description: "E.g., 'Cyberpunk Neon Heights' or 'Bioluminescent Temple Mornings'" },
                  activities: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        time: { type: Type.STRING, description: "Morning, Afternoon, or Evening" },
                        title: { type: Type.STRING },
                        description: { type: Type.STRING, description: "Immersive description of what to do" },
                        cost: { type: Type.STRING, description: "E.g., '$15 USD', 'Free', or '$200 Credits'" },
                        locationName: { type: Type.STRING, description: "E.g., 'Shibuya Sky Deck' or 'Golden Pavilion'" }
                      },
                      required: ["time", "title", "description", "cost", "locationName"]
                    }
                  }
                },
                required: ["dayNumber", "theme", "activities"]
              }
            },
            hotels: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  pricePerNight: { type: Type.STRING },
                  rating: { type: Type.STRING }
                },
                required: ["name", "description", "pricePerNight"]
              }
            },
            flightTips: { type: Type.STRING, description: "Futuristic flight hacks, low-emission travel options, or terminal shortcuts." }
          },
          required: ["destination", "country", "durationDays", "bestSeason", "budgetLevel", "description", "estimatedTotalCost", "days", "hotels", "flightTips"]
        }
      }
    });

    res.json(JSON.parse(response.text));
  } catch (error: any) {
    console.error("Itinerary generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate itinerary" });
  }
});

// Explore details endpoint
app.post("/api/explore/details", async (req, res) => {
  try {
    const { destination } = req.body;
    if (!destination) {
      return res.status(400).json({ error: "Destination is required" });
    }

    if (!hasApiKey()) {
      return res.status(400).json({ 
        error: "Gemini API key is not configured. Please add GEMINI_API_KEY to your Secrets panel." 
      });
    }

    const prompt = `Provide deep, rich explore details for the destination: "${destination}".
Give 3 local secrets, 3 signature local foods, a cultural etiquette guide, and a list of 4 ultimate highlight locations to visit.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are Lyu, providing top-tier, deep, secret insights for globetrotters. Deliver high-fidelity, creative details.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            destination: { type: Type.STRING },
            localSecrets: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3 hidden gems or insider tips unknown to regular tourists."
            },
            signatureFoods: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ["name", "description"]
              },
              description: "3 local dishes or drinks that are absolutely essential to try."
            },
            culturalEtiquette: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Key do's and don'ts for travelers to respect local culture."
            },
            highlights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  tagline: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ["name", "tagline", "description"]
              },
              description: "4 absolute must-see places."
            }
          },
          required: ["destination", "localSecrets", "signatureFoods", "culturalEtiquette", "highlights"]
        }
      }
    });

    res.json(JSON.parse(response.text));
  } catch (error: any) {
    console.error("Explore details error:", error);
    res.status(500).json({ error: error.message || "Failed to generate destination details" });
  }
});

// Vite middleware for development / serving static files
async function serveApp() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

serveApp();
