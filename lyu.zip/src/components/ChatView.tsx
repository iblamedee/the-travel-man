import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Sparkles, AlertCircle, Loader } from "lucide-react";
import { ChatMessage, TravelPreferences } from "../types";

interface ChatViewProps {
  preferences: TravelPreferences;
}

export default function ChatView({ preferences }: ChatViewProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init-message",
      role: "assistant",
      text: "Greetings, Traveler! I am Lyu, your hyper-spatial travel partner. Powered by advanced sub-orbital sub-modules, I can recommend the absolute finest hidden cyberpunk hotspots, traditional sanctuaries, or map out custom coordinates for your next destination. Tell me, where does your curiosity lead you today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestionPrompts = [
    "Recommend hidden cyberpunk bars in Tokyo",
    "What should I pack for Iceland in winter?",
    "3-day itinerary for Amalfi Coast",
    "Cultural etiquette tips for Kyoto temples"
  ];

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);
    setError(null);

    try {
      // Build full history including current user message
      const history = [...messages, userMsg].map((msg) => ({
        role: msg.role,
        text: msg.text
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: history,
          preferences: preferences
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to query AeroGPT. Please try again.");
      }

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-assistant`,
        role: "assistant",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred. Please verify your GEMINI_API_KEY in Settings.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] md:h-[100vh] w-full max-w-4xl mx-auto p-4 md:p-6">
      {/* View Header */}
      <div className="flex items-center gap-3 border-b border-white/10 pb-4 mb-4">
        <div className="w-10 h-10 rounded-full bg-brand-primary/10 border border-brand-primary/30 flex items-center justify-center text-brand-primary shadow-[0_0_15px_rgba(0,219,233,0.15)] animate-pulse">
          <Bot className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-display font-bold text-lg text-on-surface flex items-center gap-2">
            Lyu Counsel
            <span className="text-[10px] font-bold text-[#00dbe9] bg-[#00dbe9]/10 border border-[#00dbe9]/20 px-2 py-0.5 rounded uppercase tracking-wider">
              AI Partner Active
            </span>
          </h2>
          <p className="font-sans text-xs text-on-surface-variant font-medium">
            Influenced by your: <span className="text-brand-tertiary font-bold capitalize">{preferences.budget}</span> budget · <span className="text-brand-primary font-bold capitalize">{preferences.style}</span> style
          </p>
        </div>
      </div>

      {/* Messages Log area */}
      <div className="flex-1 overflow-y-auto pr-2 mb-4 space-y-4 no-scrollbar">
        {messages.map((msg) => {
          const isAssistant = msg.role === "assistant";
          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-[85%] ${isAssistant ? "mr-auto" : "ml-auto flex-row-reverse"}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  isAssistant
                    ? "bg-brand-primary/15 border border-brand-primary/20 text-brand-primary"
                    : "bg-brand-secondary/15 border border-brand-secondary/20 text-brand-secondary"
                }`}
              >
                {isAssistant ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>
              <div
                className={`p-4 rounded-2xl border text-sm leading-relaxed relative ${
                  isAssistant
                    ? "bg-[#1e1e31]/60 border-white/10 text-on-surface"
                    : "bg-brand-primary/10 border-brand-primary/25 text-on-surface rounded-tr-none"
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <span className="block text-[10px] text-on-surface-variant/50 text-right mt-2 font-mono">
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}

        {/* Loading Spinner with futuristic messages */}
        {isLoading && (
          <div className="flex gap-3 max-w-[85%] mr-auto">
            <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 bg-brand-primary/15 border border-brand-primary/20 text-brand-primary">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-4 rounded-2xl border bg-[#1e1e31]/60 border-white/10 text-on-surface flex items-center gap-3">
              <Loader className="w-4 h-4 text-brand-primary animate-spin" />
              <span className="text-xs text-on-surface-variant animate-pulse font-display font-medium">
                Plotting vector coordinates, consulting galactic travel manifests...
              </span>
            </div>
          </div>
        )}

        {/* Error panel */}
        {error && (
          <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/35 text-red-200 text-sm flex gap-3 max-w-lg mx-auto">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold mb-1">Navigation Desync</p>
              <p className="text-xs leading-relaxed text-red-300">{error}</p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Prompts */}
      {messages.length === 1 && !isLoading && (
        <div className="mb-4">
          <p className="font-display text-xs text-on-surface-variant font-bold mb-2 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-brand-primary" />
            Hyper-spatial Queries:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {suggestionPrompts.map((prompt) => (
              <button
                key={prompt}
                onClick={() => handleSendMessage(prompt)}
                className="p-3 text-left rounded-xl bg-[#1e1e31]/40 border border-white/5 text-xs text-on-surface-variant hover:text-on-surface hover:bg-[#1e1e31]/80 hover:border-brand-primary/30 transition-all duration-300 cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Send Input Area */}
      <form onSubmit={handleSubmit} className="relative z-10">
        <div className="glass-panel rounded-xl p-1.5 flex items-center gap-2 border border-white/10 focus-within:border-brand-primary/40 focus-within:shadow-[0_0_15px_rgba(0,219,233,0.15)] transition-all duration-300">
          <input
            className="flex-1 bg-transparent border-none text-on-surface font-sans text-sm placeholder:text-on-surface-variant/40 focus:ring-0 outline-none w-full h-11 px-3"
            placeholder="Ask Lyu anything about your journey..."
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="bg-brand-primary text-bg-darker p-3 rounded-lg hover:opacity-90 disabled:opacity-40 disabled:pointer-events-none transition-all flex items-center justify-center cursor-pointer tactile-btn"
          >
            <Send className="w-4 h-4 stroke-[2.5px]" />
          </button>
        </div>
      </form>
    </div>
  );
}
