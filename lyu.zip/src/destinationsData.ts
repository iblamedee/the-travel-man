import { Destination, Itinerary, ExploreDetails } from "./types";

export const initialDestinations: Destination[] = [
  {
    id: "neo-tokyo",
    name: "Neo-Tokyo",
    country: "Japan",
    tagline: "Experience the ultimate synthesis of ancient tradition and bleeding-edge cybernetics.",
    tags: ["Urban", "Nightlife", "Cyberpunk"],
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDiANDCp74Xylp4aE37bQHEPetrKLDWLSiH5MfI-XRR81KbjAunlesgYxaj3KGUxsLOQfNPyUhinzppMV0gyP_6Faq1GTBJp8bxUbHd8-x19DkNYBJlDFpL9ib6pwRY72bfnWahJE8UCQvUzLM0DkvtJWyJVz6hC1H8wvlsVN8hdVuRAGislPa6Ib563rug7Jon3y3K4bOcPqq2547yqHnHJFC7LapKIaSEPrA4r2kutEp_lsMmdD8iNoZezVMpO-nD9XE5mKEQZxly",
    description: "Experience the ultimate synthesis of ancient tradition and bleeding-edge cybernetics in the electric metropolis.",
    isHot: true
  },
  {
    id: "glacial-echoes",
    name: "Glacial Echoes",
    country: "Reykjavík, Iceland",
    tagline: "Traverse luminous ice caves and witness skies painted with magnetic storms.",
    tags: ["Nature", "Scenic", "Off-World"],
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDlWu_KsGYnSmyy_vZrAKmboOdKWBgBx9swqEFN1CY8d7vSwSLHX4mpdsLA7hdOkNmYIkSX-3gVXm-zDKorkgnJ4bXFMNJmbbYHpfpS0Bj9joi4ZYw6OFdER63jeXVNTdNwKaEQCtduQZidtCor5c6adnDZIbjEF44rQ-qv-9yTbbo-5LnaD-lNLb9TmE8fLcx2GSt5w9V_VRzPCGT94hck2r6k_4g-Qn22EXby5d_gVv8FJJ1FYmvpUgfyIhAG6Pi3Yt18xSpy5iyO",
    description: "Traverse luminous ice caves and witness skies painted with magnetic storms in this serene, frigid wilderness.",
    isHot: false
  },
  {
    id: "amalfi-heights",
    name: "Amalfi Heights",
    country: "Italy",
    tagline: "Coastal Utopias",
    tags: ["Scenic", "Relaxation", "Nature"],
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCa1PKZlyniTsAfCPmFdfzVLYza3DILkRseA_7-r6T9PHO79jHTaNsxlLoFEIML4ZJPnExDOmoISwb6A4CzoikYqlpa2Wpyt0pYRet9ayBdjX1q7F0M2CukBXZ2p_c7ndNDvfA_t6COu3rgU8XJ69IHkUabQXQeNooFdJn2lRWCxlO04quPsWlCZ_YRdZ_b6vh4cRnT0T2WOKQI4viGWt6BGp3_VlP0TdjIjtaQmJ5IbqTGk2jRZ0ViyPyA8dd7uxDxTCqIIZqCa8G5",
    description: "A striking view of the Amalfi Coast rendered with a slightly futuristic, utopian filter. Deep Mediterranean contrast.",
    isHot: false
  },
  {
    id: "zen-gardens",
    name: "Zen Gardens",
    country: "Kyoto, Japan",
    tagline: "Kyoto Sanctuaries",
    tags: ["Culture", "Nature", "Relaxation"],
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCL3EwWp_9BEJOQNssHe6idPt0UuQ673WPJR1W9AuOpQ5VQ0morouwuYPHWxCW7q2Xp64_NUz3ReTH2-ec9rOUzv4G6HdeUQYfEo2oV0abyf-p6vRRDeUrw0QkrIVZlnD1UVn_m8PDXjfYb0gvVu1f7zFtZYQy6Pdyppo5bvRmfydNNzxrbHamaKMxeKv2Rs-AzR8cT43uVXH3ohs18Mq_JlH6lKRMdOhatcIZ0Pcg6lZt0QrNIUD4ON1HDt5kgs_AwyLfrc4rWFYgX",
    description: "A serene temple garden in Kyoto, enhanced with subtle sci-fi cherry blossoms glowing with soft bioluminescence.",
    isHot: false
  }
];

// Prebaked Explore Details for instant loading
export const prebakedExploreDetails: Record<string, ExploreDetails> = {
  "neo-tokyo": {
    destination: "Neo-Tokyo",
    localSecrets: [
      "The Akihabara Sub-Grid: A hidden subterranean floor containing retro gaming hardware preserved in high-vacuum glass chambers.",
      "Omoide Yokocho Cyber-Bar: Tucked behind a holographic waterfall, this 5-seat bar serves custom neural cocktails matching your current mood.",
      "Shinjuku Gravity Garden: A pocket park featuring localized low-gravity zones where cherry blossoms float suspended in mid-air."
    ],
    signatureFoods: [
      {
        name: "Bioluminescent Ramen",
        description: "Standard tonkotsu broth infused with safe glow-algae, served under ultraviolet lights with high-specular pork belly slices."
      },
      {
        name: "Neon Gyoza",
        description: "Dumplings wrapper dyed with spinach and beetroot extract, filled with premium synthetic wagyu and explosive spices."
      },
      {
        name: "Quantum Sake",
        description: "Sake that changes temperature and color profile dynamically as you swirl the smart porcelain glass."
      }
    ],
    culturalEtiquette: [
      "Always dim your augmented reality headset when entering sacred shrines to show respect to traditional deities.",
      "Do not activate personal flight packs inside residential districts after 22:00."
    ],
    highlights: [
      {
        name: "Shibuya Crossing Flyover",
        tagline: "Spectacular multi-level holographic walkway",
        description: "Walk 150 meters above the busiest intersection in the galaxy surrounded by giant swimming digital koi fish."
      },
      {
        name: "Nakano Broadway Quantum Exchange",
        tagline: "Collector's paradise for physical artifacts",
        description: "Find real 21st-century mechanical watches, physical paper manga, and vintage non-neural computing chips."
      },
      {
        name: "Chiyoda Orbital Palace",
        tagline: "Imperial gardens with hyper-shields",
        description: "Tour the classic imperial gardens protected from heavy neon pollution by an invisible atmospheric forcefield."
      },
      {
        name: "Meguro Biolum Canal",
        tagline: "Glowing cherry blossoms",
        description: "A historic canal where bioluminescent cherry trees create a glowing pink and cyan canopy over dark reflective waters."
      }
    ]
  },
  "glacial-echoes": {
    destination: "Glacial Echoes",
    localSecrets: [
      "The Silfra Neural Well: A glacial fissure where water is so crystal clear that diving allows your mind to enter a meditative void.",
      "The Sub-thermal Hot Springs: Uncharted hot pools hidden inside natural black basalt caves accessible only via ice tunnels.",
      "The Whispering Glaciers: Areas where the sound of shifting tectonic ice resonates at therapeutic frequencies."
    ],
    signatureFoods: [
      {
        name: "Thermal Sourdough",
        description: "Traditional sweet rye bread baked in iron pots buried underground near boiling geothermal vents."
      },
      {
        name: "Aurora Smoked Char",
        description: "Arctic lake fish cold-smoked using local dried birch wood and cured with dynamic sea salt."
      },
      {
        name: "Glacier Melt Water",
        description: "Ultra-purified water harvested from 10,000-year-old deep ice core samples, served with zero-gravity ice spheres."
      }
    ],
    culturalEtiquette: [
      "Never leave marked safety trails; magnetic storms can distort GPS signals in seconds.",
      "Respect the silence of the ice fields; loud acoustic emissions are strictly regulated."
    ],
    highlights: [
      {
        name: "The Blue Lagoon Biosphere",
        tagline: "Geothermal luxury under neon skies",
        description: "Bathe in mineral-rich, milky blue water surrounded by contrasting black volcanic lava rocks and glowing auroras."
      },
      {
        name: "Vatnajökull Ice Cathedral",
        tagline: "Massive natural crystalline cavern",
        description: "Witness blue light filtered through hundreds of meters of solid glacial ice in a chamber the size of a cathedral."
      },
      {
        name: "Black Sand Matrix",
        tagline: "Reynisfjara basalt columns",
        description: "Walk on dark volcanic sands while huge basalt columns rise from the sea like giant architectural crystals."
      },
      {
        name: "Geysir Pulse Core",
        tagline: "Erupting geothermal power",
        description: "Watch Strokkur geyser release boiling water and glowing vapor plumes 30 meters into the crisp arctic air."
      }
    ]
  }
};

// Prebaked Itineraries
export const prebakedItineraries: Record<string, Itinerary> = {
  "glacial-echoes": {
    destination: "Glacial Echoes",
    country: "Iceland",
    durationDays: 3,
    bestSeason: "Late Autumn to Early Spring (Aurora Maxima)",
    budgetLevel: "Moderate",
    description: "Traverse luminous ice caves and witness skies painted with magnetic storms in this serene, frigid wilderness.",
    estimatedTotalCost: "$1,450 - $1,900 USD",
    days: [
      {
        dayNumber: 1,
        theme: "Geothermal Arrivals & Blue Bioluminescence",
        activities: [
          {
            time: "Morning",
            title: "Descent into Keflavík Void",
            description: "Arrive at Keflavík Space Terminal and board the low-emission maglev shuttle straight to the Blue Lagoon.",
            cost: "$45 USD",
            locationName: "Keflavík Space Terminal"
          },
          {
            time: "Afternoon",
            title: "Blue Biosphere Spa",
            description: "Soak in volcanic mineral baths. Apply white silica mud and watch the steam blend with cyan aurora indicators.",
            cost: "$120 USD",
            locationName: "Blue Lagoon Retreat"
          },
          {
            time: "Evening",
            title: "Volcanic Gastronomy",
            description: "Indulge in cod fillet cooked on hot basalt stone plates paired with traditional slow-baked thermal bread.",
            cost: "$65 USD",
            locationName: "Moss Restaurant"
          }
        ]
      },
      {
        dayNumber: 2,
        theme: "The Crystalline Cathedral & Magnetic Storms",
        activities: [
          {
            time: "Morning",
            title: "Super-jeep Glacier Transit",
            description: "Board a customized massive 8-wheel electric crawler designed to safely navigate high-altitude crevasses.",
            cost: "$150 USD",
            locationName: "Vatnajökull Base Camp"
          },
          {
            time: "Afternoon",
            title: "Deep Ice Cathedral Tour",
            description: "Descend into natural crystal blue caves. Touch ice that is over 10,000 years old, glowing deep cobalt.",
            cost: "$110 USD",
            locationName: "Vatnajökull Glacier Cave"
          },
          {
            time: "Evening",
            title: "Starlight Aurora Vigil",
            description: "Stand under the unpolluted night sky. Watch the solar winds dance in green and violet ribbons of neon light.",
            cost: "Free",
            locationName: "Jökulsárlón Glacier Lagoon"
          }
        ]
      },
      {
        dayNumber: 3,
        theme: "Basalt architecture & Tectonic Rifts",
        activities: [
          {
            time: "Morning",
            title: "Thingvellir Tectonic Walk",
            description: "Walk inside the dramatic Almannagjá gorge, where the North American and Eurasian tectonic plates drift apart.",
            cost: "Free",
            locationName: "Thingvellir National Park"
          },
          {
            time: "Afternoon",
            title: "Gullfoss Hydro-pulse",
            description: "Witness the roaring triple-tiered waterfall plummeting into a deep black basalt canyon filled with rainbows.",
            cost: "Free",
            locationName: "Gullfoss Waterfall"
          },
          {
            time: "Evening",
            title: "Reykjavík Tech-Bar Crawl",
            description: "Celebrate your final night with fermented shark and local craft gin in the vibrant heart of the capital.",
            cost: "$80 USD",
            locationName: "Kaffibarinn"
          }
        ]
      }
    ],
    hotels: [
      {
        name: "Ion Adventure Glass Hotel",
        description: "An architectural marvel suspended over active lava fields, featuring floor-to-ceiling glass walls for aurora viewing.",
        pricePerNight: "$350 USD",
        rating: "4.9"
      },
      {
        name: "The Reykjavik EDITION",
        description: "Ultra-luxury modern hotel located in the old harbor, blending cozy nordic design with smart tech features.",
        pricePerNight: "$420 USD",
        rating: "4.8"
      }
    ],
    flightTips: "Book a low-altitude nocturnal flight window with clear-view composite wings to experience auroras right from your seat."
  },
  "neo-tokyo": {
    destination: "Neo-Tokyo",
    country: "Japan",
    durationDays: 3,
    bestSeason: "Spring (for glowing cherry blossoms) or Autumn",
    budgetLevel: "Luxury",
    description: "Experience the ultimate synthesis of ancient tradition and bleeding-edge cybernetics in the electric metropolis.",
    estimatedTotalCost: "$2,200 - $3,500 USD",
    days: [
      {
        dayNumber: 1,
        theme: "Neon Ingress & Vertical Districts",
        activities: [
          {
            time: "Morning",
            title: "Shinkansen Hyper-arrive",
            description: "Glide into Tokyo station on the magnetic levitation train from Osaka at speeds exceeding 500 km/h.",
            cost: "$120 USD",
            locationName: "Tokyo Central Terminal"
          },
          {
            time: "Afternoon",
            title: "Akihabara Sub-Grid Shopping",
            description: "Explore five floors of mechanical components, antique retro cartridges, and high-specular holographic cards.",
            cost: "$50 USD",
            locationName: "Radio Kaikan"
          },
          {
            time: "Evening",
            title: "Shibuya Sky Deck Dinner",
            description: "Dine on high-altitude fusion sushi while looking down at millions of glowing umbrellas crossing in the rain.",
            cost: "$180 USD",
            locationName: "Shibuya Sky Deck"
          }
        ]
      },
      {
        dayNumber: 2,
        theme: "Ancients & Bioluminescence",
        activities: [
          {
            time: "Morning",
            title: "Meiji Shrine Digital Silence",
            description: "Pass through massive wooden torii gates. Augments are dimmed to absolute zero to respect the deep silent forest.",
            cost: "Free",
            locationName: "Meiji Jingu Forest"
          },
          {
            time: "Afternoon",
            title: "Interactive Art Matrix",
            description: "Wade through crystal water and touch giant digital floating spheres in a high-fidelity projection universe.",
            cost: "$35 USD",
            locationName: "teamLab Planets TOKYO"
          },
          {
            time: "Evening",
            title: "Golden Gai Cyber-Alleys",
            description: "Walk down hundreds of narrow alleys, each containing tiny custom bars. Savor glowing highballs and charcoal yakitori.",
            cost: "$90 USD",
            locationName: "Golden Gai"
          }
        ]
      },
      {
        dayNumber: 3,
        theme: "Waterfront Futurity",
        activities: [
          {
            time: "Morning",
            title: "Asakusa Traditional Heritage",
            description: "Visit Tokyo's oldest temple, Sensō-ji. Light incense and take home custom microprinted paper fortune scrolls.",
            cost: "Free",
            locationName: "Senso-ji Temple"
          },
          {
            time: "Afternoon",
            title: "Sumida Hydro-Cruise",
            description: "Board a sleek, futuristic metallic boat designed by anime legends to cruise down to Odaiba artificial island.",
            cost: "$25 USD",
            locationName: "Sumida River Cruise"
          },
          {
            time: "Evening",
            title: "Odaiba Gundam Sentinel",
            description: "Marvel at the giant 20-meter mechanical guardian transforming its armor under magenta searchlights.",
            cost: "Free",
            locationName: "Odaiba Gundam Plaza"
          }
        ]
      }
    ],
    hotels: [
      {
        name: "Hoshinoya Tokyo",
        description: "A 17-story ryokan in the business district, featuring hot springs pumped from 1,500m underground and smart tatami mats.",
        pricePerNight: "$850 USD",
        rating: "4.9"
      },
      {
        name: "Park Hyatt Neo-Tokyo",
        description: "Suspended above Shinjuku, famous for iconic skyline bar views, retro-jazz soundtrack, and stellar smart features.",
        pricePerNight: "$650 USD",
        rating: "4.7"
      }
    ],
    flightTips: "Fly Haneda terminal rather than Narita to save 40 minutes on local hyper-shuttle rails."
  }
};
